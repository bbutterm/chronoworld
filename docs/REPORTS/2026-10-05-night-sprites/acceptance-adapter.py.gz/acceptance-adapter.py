from pathlib import Path
import json,hashlib,sys,collections
from PIL import Image
import numpy as np
sys.path.insert(0,'tools')
import check_sprites,sprites_manifest
root=Path('/workspace/chronoworld'); pack=Path('/tmp/chronoworld-owner-sprites-extracted');meta=json.loads((pack/'metadata/manifest.json').read_text()); data=sprites_manifest.load();fixes=json.loads((root/'assets/sprites/fixes.json').read_text());by={s['id']:s for s in data['sprites']};checks=collections.Counter();errors=[]
for a in meta['assets']:
 sid=a['id'];s=by[sid];p=root/a['png'];c=json.loads((pack/a['contract']).read_text());checks['sheets']+=1
 assert hashlib.sha256(p.read_bytes()).hexdigest()==a['png_sha256']==c['png_sha256'],sid
 with Image.open(p) as raw:
  assert raw.mode in ('RGBA','P'),sid
  img=raw.convert('RGBA');assert list(img.size)==c['dimensions'] and max(img.size)<=2048,sid
  assert hashlib.sha256(img.tobytes()).hexdigest()==a['rgba_sha256']==c['rgba_sha256'],sid
 cfg=data['classes'][s['class']];configs={anim:{**data['anims'][anim],**data.get('animOverrides',{}).get(s['class'],{}).get(anim,{})} for anim in cfg['anims']};errors.extend(check_sprites.generated_provenance_errors(s,p,cfg,configs));cw,ch=cfg['cell'];cols=cfg.get('columns',data['columns'])
 for row,anim in enumerate(cfg['anims']):
  boxes=[];conf=configs[anim];effective=c['runtime_effective_animations'][anim];skips=fixes.get(sid,{}).get('skip',{}).get(anim,[]);selected=[col for col in range(conf['frames']) if col not in skips];expected={'frames':len(selected),'ms':[conf['ms']]*len(selected),'row':row,'source_columns':selected}
  if 'loop' in conf:expected['loop']=conf['loop']
  hit=s.get('hitFrames',{}).get(anim,conf.get('hitFrame'))
  if hit is not None:expected['hitFrame']=max(0,next((i for i,col in enumerate(selected) if col>=hit),-1))
  assert expected==effective,(sid,anim,'runtime',expected,effective);checks['exactEffectiveAnimationContracts']+=1
  for col in range(cols):
   frame=img.crop((col*cw,row*ch,(col+1)*cw,(row+1)*ch));box=check_sprites.count_and_bbox(frame)
   if col<conf['frames']:
    assert box and list(box)==c['generated_frame_bboxes'][anim][col]==s['generatedFrameBboxes'][anim][col],(sid,anim,col)
    assert 0<box[0]<box[2]<cw and 0<box[1]<box[3]<ch,(sid,anim,col,'edge')
    checks['occupiedFrameSlots']+=1;boxes.append(box)
   else:
    assert box is None,(sid,anim,col,'extra');checks['transparentSpareCells']+=1
  union=[min(b[0] for b in boxes),min(b[1] for b in boxes),max(b[2] for b in boxes),max(b[3] for b in boxes)];assert union==s['bbox'][anim]==c['runtime_union_bboxes'][anim],(sid,anim,'union')
  checks['animations']+=1;checks['effectiveRuntimeFrames']+=effective['frames']
assert not errors,errors
assert checks['sheets']==100 and checks['occupiedFrameSlots']==2400 and checks['effectiveRuntimeFrames']==2398
ids={a['id'] for a in meta['assets']};units=[];missed=[]
for p in (root/'data/units').glob('*.json'):
 j=json.loads(p.read_text())
 if j.get('kind') in ('monster','boss'):
  sid=j.get('visual',{}).get('sprite');(units if sid in ids else missed).append({'id':j['id'],'sprite':sid})
assert len(units)==124 and not missed
checks['referencingMonsterBossUnits']=len(units)
checks['uniqueSpritesUsed']=len({u['sprite'] for u in units});assert checks['uniqueSpritesUsed']==100
before=json.loads(Path('/tmp/chronoworld-sprites-before-manifest.json').read_text());preserved={p:r for p,r in before.items() if p.startswith('assets/sprites/') and p not in {a['png'] for a in meta['assets']} and p not in ('assets/sprites/sprites.json','assets/sprites/sprites.provenance.json')}
for p,r in preserved.items():assert hashlib.sha256((root/p).read_bytes()).hexdigest()==r['sha256'],p
checks['preservedOtherSpriteFiles']=len(preserved)
report={'passed':True,'checks':dict(checks),'errors':errors,'archiveSha256':hashlib.sha256(Path('/tmp/chronoworld-transfiles-download-response').read_bytes()).hexdigest(),'manifestSha256':hashlib.sha256((pack/'metadata/manifest.json').read_bytes()).hexdigest(),'spriteRuntimeSha256':hashlib.sha256((root/'assets/sprites/sprites.json').read_bytes()).hexdigest(),'spriteProvenanceSha256':hashlib.sha256((root/'assets/sprites/sprites.provenance.json').read_bytes()).hexdigest(),'spriteFixesSha256':hashlib.sha256((root/'assets/sprites/fixes.json').read_bytes()).hexdigest(),'unitDefinitions':units}
Path('/tmp/chronoworld-sprites-contract-acceptance.json').write_text(json.dumps(report,indent=1,ensure_ascii=False)+'\n');print(json.dumps({'passed':True,'checks':dict(checks)},ensure_ascii=False))
